sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel"
// We add an init function to the controller. onInit is one of SAPUI5’s lifecycle methods that is invoked 
// by the framework when the controller is created, similar to a constructor function of a control.  

], function (Controller, MessageToast, JSONModel, ResourceModel) {
        "use strict";
        return Controller.extend("sap.ui.demo.walkthrough.controller.App", {

      onShowHello : function () {
         // read msg from i18n model
         var oBundle = this.getView().getModel("i18n").getResourceBundle();
         var sRecipient = this.getView().getModel().getProperty("/recipient/name");
         var sMsg = oBundle.getText("helloMsg", [sRecipient]);
         // show message
         MessageToast.show(sMsg);
      }
   });
});
