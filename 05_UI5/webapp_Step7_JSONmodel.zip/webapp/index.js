// sap.ui.define([
//     "sap/m/Text"
// // the callback of the init event is where we now instantiate a SAPUI5 text control. 
// // The name of the control is prefixed by the namespace of its control library sap/m/ 
// //and the options are passed to the constructor with a JavaScript object.

// ], function (Text) {
//         "use strict";

//         new Text({
//                 text: "Hello World"
//         }).placeAt("content");
// //We chain the constructor call of the control to the standard method placeAt that is used 
// //to place SAPUI5 controls inside a node of the document object model (DOM) 
// //or any other SAPUI5 control instance. We pass the ID of a DOM node as an argument. 
// //As the target node we use the body tag of the HTML document and give it the ID content.

// });

//We replace the instantiation of the sap.m.Text control by our new App XML view. 
//The view is created by a factory function of SAPUI5 which makes sure that the view 
//is correctly configured and can be extended by customers. The name is prefixed with the namespace 
//sap.ui.demo.walkthrough.view in order to uniquely identify this resource.

sap.ui.define([
    "sap/ui/core/mvc/XMLView"
], function (XMLView) {
    "use strict";

    XMLView.create({
		viewName: "sap.ui.demo.walkthrough.view.App"
	}).then(function (oView) {
		oView.placeAt("content");
	});

});