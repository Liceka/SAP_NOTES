sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel"
// We add an init function to the controller. onInit is one of SAPUI5’s lifecycle methods that is invoked 
// by the framework when the controller is created, similar to a constructor function of a control.  

], function (Controller, MessageToast, JSONModel) {
        "use strict";
        return Controller.extend("sap.ui.demo.walkthrough.controller.App", {
            onInit : function () {
         // set data model on view
//Inside the function we instantiate a JSON model. The data for the model only contains a single property 
//for the “recipient”, and inside this it also contains one additional property for the name.
                var oData = {
                    recipient : {
                        name : "world"
                    }
                };
//To be able to use this model from within the XML view, we call the setModel function on the view 
//and pass on our newly created model. The model is now set on the view.
                var oModel = new JSONModel(oData);
                this.getView().setModel(oModel);
             },
//The message toast is just showing the static "Hello World" message             
             onShowHello : function () {
                MessageToast.show("Hello World");
             }
          });
       });
