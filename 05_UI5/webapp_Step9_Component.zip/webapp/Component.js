sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel"
], function (UIComponent, JSOBModel, ResourceModel) {
    "use strict";

    //The new metadata section that simply defines a reference to the root view 
    // and the previously introduced init function that is called when the component 
    // is initialized. Instead of displaying the root view directly in the index.js file 
    // as we did previously, the component will now manage the display of the app view.
    
    return UIComponent.extend("sap.ui.demo.walkthrough.Component", {
        metadata : {
           "interfaces": ["sap.ui.core.IAsyncContentCreation"],
           "rootView": {
              "viewName": "sap.ui.demo.walkthrough.view.App",
              "type": "XML",
              /*"async": true, // implicitly set via the sap.ui.core.IAsyncContentCreation interface*/
              "id": "app"
           }
        },

// We instantiate our data model and the i18n model like we did before in the app 
// controller. Be aware that the models are directly set on the component and not 
// on the root view of the component      
        init : function () {
            // call the init function of the parent
            UIComponent.prototype.init.apply(this, arguments);
            // set data model
         var oData = {
            recipient : {
               name : "World"
            }
         };
         var oModel = new JSONModel(oData);
         this.setModel(oModel);

         // set i18n model
         var i18nModel = new ResourceModel({
            bundleName: "sap.ui.demo.walkthrough.i18n.i18n"
         });
         this.setModel(i18nModel, "i18n");
        }
    });
});
