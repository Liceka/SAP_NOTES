sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
        "use strict";
        return Controller.extend("sap.ui.demo.walkthrough.controller.App", {
            onShowHello : function () {
         // show a native JavaScript alert
         alert("Hello World");
            }
        });
});

// We define the app controller in its own file by extending the Controller object of the SAPUI5 core. 
// In the beginning it holds only a single function called onShowHello that handles the button's press event 
// by showing an alert.